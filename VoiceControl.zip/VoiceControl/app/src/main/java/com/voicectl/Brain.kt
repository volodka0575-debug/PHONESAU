package com.voicectl

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.view.KeyEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import kotlin.random.Random

/** Основы слова (маме → мам), чтобы падежи не мешали искать чаты, контакты и приложения. */
fun stems(s: String) = listOf(s, s.dropLast(1), s.dropLast(2)).filter { it.length >= 3 }.distinct()

/** «Мозг»: разбирает фразу на команды, выполняет их и отвечает голосом. */
object Brain {
    val logs = CopyOnWriteArrayList<String>()
    @Volatile var running = false
    @Volatile var onLog: (() -> Unit)? = null
    @Volatile var dict: ((String) -> Unit)? = null
    @Volatile var dictUntil = 0L
    @Volatile var say: ((String, String) -> Unit)? = null
    @Volatile private var lastSug = ""
    private var appCtx: Context? = null
    private val ex = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private const val NOACC = "Не включена служба доступности. Включи её в настройках, в специальных возможностях"
    private const val EXACT = "Не получилось поставить. Разреши приложению точные будильники в настройках"
    private const val VERBS = "открой|открыть|запусти|зайди|войди|выйди|включи|введи|набери|напиши|отправь|нажми|найди|закрой|назад|домой|прокрути|пролистай|листай|стоп|пауза|продолжай|разблокируй|заблокируй|громче|тише|скриншот|вернись|выбери|кликни|очисти|перейди|сверни|вниз|вверх|следующее|позвони"
    private val SINGLE = Regex("^(?:(?:поставь|установи|заведи|сделай|засеки|запусти|включи) )?(?:таймер|будильник)|^напомни|^разбуди меня|^запомни|^запиши|^создай заметку|^напиши в заметки|^переведи|^как (?:на|по)")
    private val INSTANT = Regex("(?:стоп|пауза|хватит|тихо|следующ\\S*|дальше|предыдущ\\S*|продолжай|громче|тише|пропусти)")

    private val DW = mapOf("ноль" to "0", "один" to "1", "два" to "2", "три" to "3", "четыре" to "4",
        "пять" to "5", "шесть" to "6", "семь" to "7", "восемь" to "8", "девять" to "9")
    private fun digits(s: String) = s.split(" ").joinToString("") { DW[it] ?: it }.filter { it.isDigit() }

    private val AL = listOf("ютуб|ютьюб" to "youtube", "телеграм+" to "telegram", "вацап|ватсап|вотсап|ватцап" to "whatsapp",
        "вайбер" to "viber", "хром|браузер" to "chrome", "инстаграм+" to "instagram", "тикток|тик ток" to "tiktok",
        "вк|вконтакте" to "vk", "гугл" to "google", "карты" to "maps", "почта" to "gmail",
        "плей маркет|гугл плей|магазин приложений" to "play", "нетфликс" to "netflix", "спотифай" to "spotify",
        "дискорд" to "discord", "твитч" to "twitch", "настройки" to "settings", "камера" to "camera",
        "галерея|фото" to "photos", "калькулятор" to "calculator", "часы|будильник" to "clock",
        "контакты" to "contacts", "телефон" to "phone", "сообщения" to "messages", "файлы" to "files",
        "музыка" to "music", "яндекс" to "yandex", "заметк\\S*|блокнот" to "заметки|notes|keep|заметка")

    private val QS = listOf("вай ?фай|wi-?fi|вай-фай" to listOf("wi-fi", "интернет", "internet"),
        "блютуз|bluetooth" to listOf("bluetooth"), "режим полета|режим в самолете|авиарежим" to listOf("режим полета", "airplane", "в самолете"),
        "не беспокоить" to listOf("не беспокоить", "do not disturb"), "автоповорот" to listOf("автоповорот", "auto-rotate", "auto rotate"),
        "мобильный интернет|мобильные данные" to listOf("мобильный интернет", "мобильные данные", "mobile data"),
        "геолокаци\\S*|локаци\\S*" to listOf("геолокация", "местоположение", "location"),
        "точку доступа|хотспот" to listOf("точка доступа", "hotspot"))

    // ---------- вывод и голос ----------
    private fun pf(k: String) = appCtx?.getSharedPreferences("vc", 0)?.getBoolean(k, true) ?: true
    fun log(m: String) { logs.add(m); while (logs.size > 25) logs.removeAt(0); ui.post { onLog?.invoke() } }
    private fun say0(m: String, lang: String = "ru", force: Boolean = false) { if (force || pf("voice")) say?.invoke(m, lang) }
    fun speak(m: String, lang: String = "ru", force: Boolean = false) { log("🔊 $m"); say0(m, lang, force) }
    fun answer(m: String, lang: String = "ru") = speak(m, lang, true)
    private fun ok(m: String) { log("✔ $m"); say0(if (pf("cute") && Random.nextInt(100) < 30) Phrases.cute() + " " + m else m) }
    private fun fail(m: String) { log("✖ $m"); say0(m) }
    private fun chat(p: String) = say0(if (pf("cute")) p else "Слушаю")

    fun norm(s: String) = s.lowercase().replace('ё', 'е').replace(Regex("[\"«»“”„]"), "").trim()
    fun names(c: Context) = (c.getSharedPreferences("vc", 0).getString("names", "джарвис") ?: "джарвис")
        .split(",").map { norm(it) }.filter { it.isNotEmpty() }
    fun isInstant(cmd: String) = INSTANT.matches(cmd)

    fun startDictation(cb: (String) -> Unit) { dictUntil = SystemClock.elapsedRealtime() + 30000; dict = cb }
    fun deliver(cb: (String) -> Unit, t: String) = ex.execute { try { cb(t) } catch (e: Exception) { log("✖ ${e.message}") } }

    private fun locked(c: Context) = c.getSystemService(KeyguardManager::class.java).isKeyguardLocked
    private fun clean(s0: String): String {
        var s = " $s0 "
        for (f in listOf("пожалуйста", "слушай", "эй", "будь добр", "а ну", "ну", "давай-ка")) s = s.replace(" $f ", " ")
        return s.trim().replace(Regex("\\s+"), " ")
    }

    fun go(c: Context, text: String) = ex.execute {
        appCtx = c.applicationContext
        Music.init(c)
        log("▶ $text")
        val parts = if (SINGLE.containsMatchIn(text)) listOf(text)
            else text.split(Regex("\\s+(?:и|потом|затем|после этого|а потом)\\s+(?=(?:$VERBS)(?:\\s|$))"))
        for (p in parts) {
            try { exec(c, p.trim()) } catch (e: Exception) { fail("Ошибка: ${e.message}") }
            Thread.sleep(900)
        }
    }

    @Suppress("DEPRECATION")
    fun wake(c: Context) {
        c.getSystemService(PowerManager::class.java).newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
            "voicectl:wake").acquire(8000)
    }

    private fun media(am: AudioManager, k: Int) {
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, k))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, k))
    }

    private fun vol(am: AudioManager, dir: Int) {
        repeat(3) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, if (it == 2) AudioManager.FLAG_SHOW_UI else 0) }
    }

    private fun pl(n: Long, one: String, few: String, many: String) =
        if (n % 100 in 11..19) many else when (n % 10) { 1L -> one; 2L, 3L, 4L -> few; else -> many }

    private fun human(ms: Long): String {
        val s = ms / 1000; val h = s / 3600; val m = s % 3600 / 60; val sec = s % 60
        return listOfNotNull(if (h > 0) "$h ${pl(h, "час", "часа", "часов")}" else null,
            if (m > 0) "$m ${pl(m, "минуту", "минуты", "минут")}" else null,
            if (sec > 0) "$sec ${pl(sec, "секунду", "секунды", "секунд")}" else null).joinToString(" ")
    }

    private fun hhmm(at: Long) = SimpleDateFormat("H:mm", Locale("ru")).format(Date(at))

    // ---------- приложения ----------
    private fun waitPkg(a: ControlService, pkg: String, ms: Long): Boolean {
        val end = SystemClock.elapsedRealtime() + ms
        while (SystemClock.elapsedRealtime() < end) { if (a.currentPkg() == pkg) return true; Thread.sleep(250) }
        return false
    }

    /** true — приложение найдено (даже если открыть не удалось: причина озвучена). */
    private fun openApp(c: Context, a: ControlService?, name: String, quiet: Boolean): Boolean {
        val pm = c.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val low = apps.map { it.first.lowercase().replace('ё', 'е') }
        val keys = stems(name).ifEmpty { listOf(name) }.toMutableList()
        AL.forEach { if (Regex("(?:${it.first})\\S*").matches(name)) keys.addAll(it.second.split("|")) }
        var idx = -1
        for (k in keys) {
            idx = low.indexOfFirst { it == k }
            if (idx < 0) idx = low.indexOfFirst { it.contains(k) }
            if (idx >= 0) break
        }
        if (idx < 0) {
            val ranked = low.indices.sortedByDescending { fz(name, low[it]) }
            lastSug = ranked.take(3).joinToString(", ") { apps[it].first }
            if (ranked.isNotEmpty() && fz(name, low[ranked[0]]) >= 0.72) idx = ranked[0]
            else { if (!quiet) fail("Не нашёл приложение $name. Похожие: $lastSug"); return false }
        }
        val label = apps[idx].first; val pkg = apps[idx].second
        if (locked(c)) { fail("Экран заблокирован, не могу открыть $label. Скажи: разблокируй"); return true }
        val intent = pm.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent == null) { fail("$label нельзя запустить"); return true }
        try { (a ?: c).startActivity(intent) } catch (e: Exception) { fail("Система не даёт открыть $label: ${e.message}"); return true }
        log("↗ Открываю $label")
        if (a == null) { Thread.sleep(1500); return true }
        if (!waitPkg(a, pkg, 4000)) {
            a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); Thread.sleep(800)
            if (!(a.clickText(low[idx]) && waitPkg(a, pkg, 3500))) {
                val why = if (!Settings.canDrawOverlays(c)) "Система блокирует запуск из фона. В приложении нажми пункт показ поверх других окон"
                    else "Телефон не пустил приложение на экран. Разреши для Голосового управления автозапуск и всплывающие окна"
                fail("Не смог открыть $label. $why")
                return true
            }
        }
        Thread.sleep(900)
        ok("Открыл $label")
        return true
    }

    // ---------- звонки, музыка, сообщения ----------
    private fun findContact(c: Context, q: String): Pair<String, String>? {
        try {
            val rows = ArrayList<Pair<String, String>>()
            c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null, null)?.use { cu -> while (cu.moveToNext()) rows.add(norm(cu.getString(0) ?: "") to (cu.getString(1) ?: "")) }
            val ks = stems(q).ifEmpty { listOf(q) }
            for (k in ks) rows.firstOrNull { it.first == k }?.let { return it }
            for (k in ks) rows.firstOrNull { it.first.contains(k) }?.let { return it }
            rows.maxByOrNull { fz(q, it.first) }?.let { if (fz(q, it.first) >= 0.8) return it }
        } catch (e: Exception) { fail("Нет доступа к контактам. Выдай разрешение") }
        return null
    }

    private fun call(c: Context, a: ControlService?, who: String) {
        var num = digits(who); var name = who
        if (num.length < 5) {
            val r = findContact(c, who)
            if (r == null) { fail("Не нашёл контакт $who"); return }
            num = r.second; name = r.first
        }
        try { (a ?: c).startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); ok("Звоню $name") }
        catch (e: Exception) { fail("Не могу позвонить: ${e.message}") }
    }

    private fun telecom(c: Context, accept: Boolean) {
        val tm = c.getSystemService(TelecomManager::class.java)
        try { if (accept) tm.acceptRingingCall() else tm.endCall() } catch (e: Exception) { fail("Нет разрешения управлять звонками") }
    }

    private fun libReady(c: Context): Boolean {
        if (Music.count() == 0) {
            try { Music.rescan() } catch (e: Exception) { fail("Нет доступа к музыке. Выдай разрешение на аудио в приложении"); return false }
        }
        if (Music.count() == 0) { fail("На устройстве не нашёл музыки"); return false }
        return true
    }

    private fun playLocal(c: Context, q: String) {
        if (!libReady(c)) return
        val res = if (q.isBlank()) Music.all() else Music.search(q)
        if (res.isEmpty()) { fail("Не нашёл в музыке: $q"); return }
        Music.play(res, shuffle = q.isBlank() || res.size >= 5)
        ok("Включаю ${Music.nowPlaying()}")
    }

    private fun yandex(c: Context, y: ControlService, kind: String, q: String) {
        if (y.currentPkg()?.contains("yandex.music") != true && !openApp(c, y, "яндекс музыка", false)) return
        val done = when {
            kind.contains("волн") || q.isBlank() -> y.clickAny("моя волна", "волна", "my wave")
            kind.contains("плейлист") -> y.yandexPlay(q, true)
            else -> y.yandexPlay(q, false)
        }
        if (done) ok("Включаю в Яндекс Музыке") else fail("Не получилось найти в Яндекс Музыке: $q")
    }

    private fun typeSend(a: ControlService, txt: String) {
        if (!a.typeSmart(cap(txt))) { fail("Не вижу поле ввода. Открой чат и нажми на строку сообщения"); return }
        Thread.sleep(400)
        if (a.clickAny("отправить", "send") || a.enter()) ok("Отправил") else fail("Не нашёл кнопку отправки")
    }

    private fun chatFlow(c: Context, a: ControlService?, app: String, chat: String) {
        if (a == null) { fail(NOACC); return }
        if (!openApp(c, a, app, false)) return
        a.toRoot()
        openApp(c, a, app, true)
        if (!a.openChat(chat)) { fail("Не нашёл чат $chat. Я ищу по названию на экране и через поиск. Проверь, как чат называется в приложении"); return }
        Thread.sleep(900)
        speak("Диктуйте сообщение", force = true)
        startDictation { typeSend(a, it) }
    }

    private fun noteFlow(c: Context, a: ControlService?, text: String?) {
        fun internal(why: String) {
            if (text != null) { Notes.add(c, cap(text)); ok("Записал во внутренние заметки, потому что $why") }
            else { speak("Диктуйте заметку. Сохраню во внутренние, потому что $why", force = true); startDictation { Notes.add(c, cap(it)); ok("Записал") } }
        }
        if (a == null) return internal("служба доступности выключена")
        if (locked(c)) return internal("экран заблокирован")
        if (!openApp(c, a, "заметки", true)) return internal("не нашёл приложение заметок")
        if (a.editField() == null) { a.clickAny("создать", "новая заметка", "new note", "create", "добавить", "add"); Thread.sleep(1000) }
        if (a.editField() == null) { a.fab(); Thread.sleep(1000) }
        val write = { t: String -> if (a.setText(cap(t), false, true)) ok("Записал") else fail("Не нашёл поле заметки") }
        if (text != null) write(text) else { speak("Диктуйте заметку", force = true); startDictation { write(it) } }
    }

    private fun torch(c: Context, on: Boolean) {
        val cm = c.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return
        cm.setTorchMode(id, on)
    }

    private fun translate(text: String, code: String) {
        val r = Net.translate(text, code)
        if (r == null) { fail("Не получилось перевести. Проверь интернет"); return }
        answer("Перевод:"); answer(r, code)
    }

    // ---------- разбор команды ----------
    private fun exec(c: Context, s0: String) {
        val s = clean(s0)
        val sn = numWords(s)
        val a = ControlService.inst
        fun f(p: String) = Regex(p).find(s)?.groupValues
        fun fn(p: String) = Regex(p).find(sn)?.groupValues
        fun t(p: String) = Regex(p).matches(s)
        fun has(p: String) = Regex(p).containsMatchIn(s)
        fun acc(allowLocked: Boolean = false, b: (ControlService) -> Unit) {
            if (a == null) return fail(NOACC)
            if (!allowLocked && locked(c)) return fail("Экран заблокирован. Скажи: разблокируй")
            b(a)
        }
        val am = c.getSystemService(AudioManager::class.java)

        // --- милое общение ---
        if (t("привет\\S*|здравствуй\\S*|хай|ку|добрый день|салют|здарова")) return chat(Phrases.hello())
        if (t("доброе утро|с добрым утром")) return chat(Phrases.morning())
        if (t("добрый вечер")) return chat(Phrases.evening())
        if (t("спокойной ночи|сладких снов|я спать|пойду спать|доброй ночи")) { if (Music.active) Music.stop(); return chat(Phrases.night()) }
        if (t("как дела|как ты|как настроение|как жизнь")) return chat(Phrases.how())
        if (t("спасибо|благодарю|спасибочки|мерси")) return chat(Phrases.thanks())
        if (t("ты молодец|молодец|умница|ты лучший|ты умница")) return chat(Phrases.praise())
        if (t("я тебя люблю|люблю тебя|ты мне нравишься|ты классный")) return chat(Phrases.love())
        if (t("кто ты|как тебя зовут|что ты умеешь|что ты можешь")) return answer(Phrases.about())
        if (t("расскажи (?:шутку|анекдот)|пошути|рассмеши меня")) return answer(Phrases.joke())
        if (t("ты тут|ты здесь|ты слышишь меня|ты меня слышишь|проверка")) return chat(Phrases.here())

        // --- переводчик ---
        val tm = Regex("^(?:как|переведи) (?:(?:будет|сказать|переводится|звучит|перевести) )?(?:на|по)[- ]?(\\S+?) (?:(?:будет|это|слово|фразу|сказать) )*(.+)$").find(s)?.let { it.groupValues[1] to it.groupValues[2] }
            ?: Regex("^(?:как|переведи) (?:(?:будет|сказать|переводится|звучит|перевести) )?(.+) (?:на|по)[- ]?(\\S+?)$").find(s)?.let { it.groupValues[2] to it.groupValues[1] }
        if (tm != null) { val code = Net.lang(tm.first); if (code != null) return translate(tm.second, code) }

        // --- экран, замок ---
        if (t("(?:(?:включи|разбуди|активируй|зажги) (?:планшет|телефон|экран|устройство))|проснись|разбуди")) { wake(c); return ok("Экран включён") }
        if (t("выключись|отключись|завершить работу|прекрати слушать|спи")) { c.stopService(Intent(c, VoiceService::class.java)); return }
        if (s.startsWith("разблок") || s.startsWith("сними блокировку") || has("^(?:введи |набери )?(?:пароль|пин|код)")) {
            val d = digits(s).ifEmpty { c.getSharedPreferences("vc", 0).getString("pin", "") ?: "" }
            wake(c); Thread.sleep(800)
            return acc(true) { it.unlock(d); ok("Разблокировка") }
        }
        if (t("(?:заблокируй|выключи)(?: (?:экран|планшет|телефон|устройство))?|усни"))
            return acc(true) { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN); ok("Экран заблокирован") }

        // --- будильник звонит ---
        if (RingService.ringing && t("(?:выключи|останови|отключи|выруби|стоп|хватит|тихо|замолчи|хорош|ладно)(?: (?:будильник|таймер|сигнал|звонок|напоминание|музыку|звук))?")) {
            RingService.stop(c); Music.stop(); return ok("Выключил")
        }

        // --- таймеры, будильники, напоминания ---
        val tp = "(?:(?:поставь|установи|заведи|сделай|засеки|запусти|включи) )?"
        if (Regex("^${tp}таймер").containsMatchIn(s)) {
            val (r0, song) = splitSong(s.replace(Regex("^${tp}таймер ?(?:на |через )?"), ""))
            val d = parseDur(numWords(r0)) ?: return fail("Не понял, на сколько поставить таймер")
            if (!Sched.add(c, System.currentTimeMillis() + d.first, "timer", "", song ?: "")) return fail(EXACT)
            return ok("Таймер на ${human(d.first)}" + if (song != null) ", с песней $song" else "")
        }
        if (Regex("^${tp}будильник|^разбуди меня").containsMatchIn(s)) {
            val tomorrow = s.contains("завтра")
            val (r0, song) = splitSong(s.replace(Regex("^${tp}будильник ?|^разбуди меня ?"), "").replace("завтра", "").trim())
            val ck = parseClock(numWords(r0), tomorrow) ?: return fail("Не понял время будильника")
            if (!Sched.add(c, ck.first, "alarm", "", song ?: "")) return fail(EXACT)
            return ok("Будильник на ${hhmm(ck.first)}" + if (song != null) ", с песней $song" else "")
        }
        f("^напомни(?: мне)? (.+)")?.let { g ->
            val tomorrow = g[1].contains("завтра")
            val body = numWords(g[1].replace("завтра", "").trim())
            val now = System.currentTimeMillis()
            var at = 0L; var text = ""
            val d = if (body.startsWith("через ")) parseDur(body.removePrefix("через ")) else null
            if (d != null) { at = now + d.first; text = d.second }
            else {
                val ck = parseClock(body, tomorrow)
                if (ck != null) { at = ck.first; text = ck.second }
                else {
                    val m1 = Regex("^(.+?) через (.+)$").find(body); val d1 = m1?.let { parseDur(it.groupValues[2]) }
                    val m2 = Regex("^(.+?) (?:в|на|к) (\\d.*)$").find(body); val c2 = m2?.let { parseClock(it.groupValues[2], tomorrow) }
                    if (m1 != null && d1 != null) { at = now + d1.first; text = m1.groupValues[1] }
                    else if (m2 != null && c2 != null) { at = c2.first; text = m2.groupValues[1] }
                }
            }
            text = text.replace(Regex("^(?:что |про |о |об |чтобы |что нужно )"), "").trim()
            if (at == 0L) return fail("Не понял, когда напомнить")
            if (text.isBlank()) return fail("О чём напомнить?")
            if (!Sched.add(c, at, "reminder", cap(text), "")) return fail(EXACT)
            return ok("Напомню в ${hhmm(at)}: $text")
        }
        if (t("(?:отмени|удали|сбрось|убери|выключи) (?:все )?(?:таймеры|будильники|напоминания|таймер|будильник|напоминание)")) return ok("Отменил: ${Sched.cancelAll(c)}")
        if (t("(?:какие|покажи|что за) (?:у меня )?(?:будильники|таймеры|напоминания).*")) {
            val l = Sched.list(c)
            return answer(if (l.isEmpty()) "Ничего не поставлено" else l.joinToString(". ") {
                (when (it[2]) { "timer" -> "Таймер"; "reminder" -> "Напоминание"; else -> "Будильник" }) + " в " + hhmm(it[1].toLong()) + (if (it[3].isNotBlank()) ", " + it[3] else "") })
        }

        // --- внутренние заметки ---
        f("^запомни(?: что)? (.+)")?.let { g -> Notes.add(c, cap(g[1])); return ok("Запомнил") }
        if (t("что ты запомнил|прочитай (?:мои )?заметки|что в заметках|мои заметки")) {
            val l = Notes.all(c); return answer(if (l.isEmpty()) "Заметок нет" else "Заметки: " + l.joinToString(". "))
        }
        if (t("(?:удали|очисти|сотри) (?:все )?заметки")) { Notes.clear(c); return ok("Заметки удалены") }

        // --- справка ---
        if (t("который час|сколько времени|скажи время|время|сколько сейчас времени")) return answer("Сейчас " + SimpleDateFormat("H:mm", Locale("ru")).format(Date()))
        if (t("какое сегодня число|какой сегодня день|какая сегодня дата|какое число|какой день недели|какой сегодня день недели"))
            return answer("Сегодня " + SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(Date()))
        if (t("сколько заряда|уровень заряда|сколько процентов|заряд|сколько осталось заряда|сколько батарея"))
            return answer("Заряд ${c.getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} процентов")
        if (t("(?:какая )?погода.*|что за погода.*")) {
            val w = Net.weather() ?: return fail("Не получилось узнать погоду. Проверь интернет")
            return answer("Сейчас $w")
        }
        if (t("сколько (?:у меня )?песен|сколько музыки")) return answer("В базе ${Music.count()} песен")
        f("^(?:сколько будет|сколько|посчитай|вычисли|реши|подсчитай|чему равно|чему равен|калькулятор) (.+)")?.let { g ->
            val r = calc(g[1]); return if (r != null) answer("Ответ: $r") else fail("Не смог посчитать")
        }
        if (t("(?:подбрось|брось|кинь) монетку")) return answer(if (Random.nextBoolean()) "Орёл" else "Решка")
        if (t("(?:брось|кинь|подбрось) кубик")) return answer("Выпало ${Random.nextInt(1, 7)}")

        // --- устройство ---
        if (t("(?:найди|где) (?:мой )?(?:телефон|планшет|устройство)|позвони мне|я потерял (?:телефон|планшет)")) {
            c.startForegroundService(Intent(c, RingService::class.java).putExtra("kind", "find").putExtra("text", "Я здесь!"))
            return ok("Звоню, ищи меня")
        }
        f("^(включи|выключи|вырубь|зажги|потуши|выруби) (?:фонарик|фонарь)")?.let { g ->
            val on = g[1] == "включи" || g[1] == "зажги"
            torch(c, on); return ok(if (on) "Фонарик включён" else "Фонарик выключен")
        }
        fn("^громкость(?: на)? (\\d+)")?.let { g ->
            val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, mx * g[1].toInt().coerceIn(0, 100) / 100, AudioManager.FLAG_SHOW_UI)
            return ok("Громкость ${g[1]} процентов")
        }
        f("^(?:включи|выключи|переключи|отключи|вруби|выруби) (.+)")?.let { g ->
            QS.firstOrNull { Regex(it.first).matches(g[1]) }?.let { q ->
                return acc { y -> if (y.qsToggle(q.second)) ok("Переключил ${g[1]}") else fail("Не нашёл переключатель ${g[1]} в быстрых настройках") }
            }
        }

        // --- музыка и медиа ---
        if (t("(?:обнови|пересканируй|просканируй|сканируй) (?:мою )?(?:музыку|базу музыки|медиатеку|песни)")) {
            return try { answer("В базе музыки ${Music.rescan()} песен") } catch (e: Exception) { fail("Нет доступа к музыке. Выдай разрешение на аудио") }
        }
        if (has("^(?:выключи|останови|заверши|закончи|прекрати) (?:музыку|песню|плеер)")) { Music.stop(); media(am, KeyEvent.KEYCODE_MEDIA_PAUSE); return ok("Музыка выключена") }
        if (has("^(?:стоп|пауз|стой|хватит|останови|замри|тихо|поставь на пауз)")) {
            if (Music.active) Music.pause() else media(am, KeyEvent.KEYCODE_MEDIA_PAUSE); return ok("Пауза")
        }
        if (has("^(?:продолж|играй|воспроизв|плей|снова|давай дальше|включи видео|запусти видео)")) {
            if (Music.active) Music.resume() else media(am, KeyEvent.KEYCODE_MEDIA_PLAY); return ok("Продолжаю")
        }
        if (has("^(?:следующ|дальше|пропусти|вперед)")) { if (Music.active) Music.next() else media(am, KeyEvent.KEYCODE_MEDIA_NEXT); return ok("Следующая") }
        if (has("^(?:предыдущ|прошлую|прошлый)")) { if (Music.active) Music.prev() else media(am, KeyEvent.KEYCODE_MEDIA_PREVIOUS); return ok("Предыдущая") }
        if (t("что (?:сейчас )?играет|как называется (?:эта )?песня|что за песня")) return answer(if (Music.active) Music.nowPlaying() else "Сейчас ничего не играет")
        if (has("^(?:громче|погромче|прибавь)")) { vol(am, AudioManager.ADJUST_RAISE); return ok("Громче") }
        if (has("^(?:тише|потише|убавь)")) { vol(am, AudioManager.ADJUST_LOWER); return ok("Тише") }
        if (t("без звука|выключи звук|убери звук")) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); return ok("Без звука") }
        if (t("включи (?:что-нибудь|что нибудь|случайную песню|любую песню|какую-нибудь песню)")) return playLocal(c, "")
        val yTail = has(" (?:в|на|через) яндекс музык\\S*$")
        val body = s.replace(Regex(" (?:в|на|через) яндекс музык\\S*$"), "")
        Regex("^(?:включи|запусти|поставь|играй|найди|воспроизведи|врубай) (мой плейлист|плейлист|песню|трек|альбом|исполнителя|музыку|мою волну|волну|композицию)(?: (.+))?$")
            .find(body)?.groupValues?.let { g ->
                val inY = yTail || a?.currentPkg()?.contains("yandex.music") == true
                if (inY) return acc { y -> yandex(c, y, g[1], g[2].trim()) }
                return playLocal(c, g[2].trim())
            }

        // --- звонки ---
        f("^(?:позвони|звони|вызови|набери номер)(?: (?:на|по))?(?: (?:номер|контакту|абоненту))? (.+)")?.let { g -> return call(c, a, g[1]) }
        if (t("(?:ответь|возьми трубку|прими вызов|ответить)(?: на (?:звонок|вызов))?")) { telecom(c, true); return ok("Ответил") }
        if (t("сбрось|положи трубку|заверши (?:звонок|вызов)|отклони(?: звонок| вызов)?")) { telecom(c, false); return ok("Вызов завершён") }
        if (t("(?:включи )?громкую связь|на громкую")) { am.isSpeakerphoneOn = true; return ok("Громкая связь") }

        // --- сообщения (чат -> диктовка -> отправка) и заметки в приложении ---
        val app = "(телеграм\\S*|телеге|телегу|вацап\\S*|ватсап\\S*|вайбер\\S*)"
        (f("^(?:напиши|отправь|пошли|шли)(?: сообщение)? (?:в |во )?$app (?:(?:в чат|в чате|в диалог) )?(?:с |со )?(.+)")?.let { it[1] to it[2] }
            ?: f("^(?:напиши|отправь|пошли|шли)(?: сообщение)? (.+?) (?:в|во) $app$")?.let { it[2] to it[1] })
            ?.let { (ap, who) -> return chatFlow(c, a, ap, who) }
        f("^(?:запиши|напиши|добавь|создай|сделай)(?: (?:в|во))?(?: новую)? заметк\\S*(?: (.+))?$")?.let { g -> return noteFlow(c, a, g[1].ifBlank { null }) }

        // --- анализ экрана ---
        if (t("прочитай экран|что на экране|что на экране написано")) return acc { answer(it.screenText().ifBlank { "Ничего не вижу" }) }
        if (t("закрой (?:крестик|окно|рекламу|это|диалог|вкладку|баннер|объявление)"))
            return acc { if (it.smartClick("закрыть")) ok("Закрыл") else fail("Не вижу, что закрыть") }

        // --- навигация ---
        if (t("домой|на главный.*|главный экран|рабочий стол|на рабочий стол|выйди.*|выйти.*|выход.*|закрой|закрой приложение|сверни.*"))
            return acc { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); ok("Домой") }
        if (t("назад|вернись.*|вернуться.*|шаг назад"))
            return acc { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); ok("Назад") }
        if (t("недавние.*|последние приложения|переключи приложени.*|покажи приложения|многозадачность"))
            return acc { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS); ok("Недавние") }
        if (t("(?:покажи |открой )?(?:уведомления|шторк\\S*)"))
            return acc { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); ok("Шторка") }
        if (t("(?:открой )?быстрые настройки"))
            return acc { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS); ok("Быстрые настройки") }
        if (t("(?:сделай )?(?:скриншот|снимок экрана)"))
            return acc { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT); ok("Скриншот") }
        f("^(?:(?:прокрути|пролистай|листай|свайпни|свайп|скролл|двигай) )?(вниз|вверх|влево|вправо)$")?.let { g ->
            return acc { it.scroll(g[1]); ok("Прокрутка ${g[1]}") }
        }

        // --- результаты, чаты, поиск ---
        if (has("^(?:(?:включи|открой|выбери|нажми на|запусти|зайди в|давай) )?(?:самое |самый )?перв\\S*"))
            return acc { it.firstResult(); ok("Первый результат") }
        f("^(?:открой|зайди|войди|перейди|найди)(?: в| к| на)? (?:чат|диалог|переписку|беседу) (?:с |со |у )?(.+)")?.let { g ->
            return acc { if (it.openChat(g[1])) ok("Чат: ${g[1]}") else fail("Не нашёл чат ${g[1]} на экране. Открой список чатов и повтори") }
        }
        (f("^(?:введи|набери|напиши|вбей|впиши|найди|ищи|поищи) (?:в )?(?:поиске|поиск|поисковой строке|строке поиска|поле поиска|поисковике)(?: по)? (.+)")
            ?: f("^(?:найди|ищи|поищи|поиск|вбей в поиск) (.+)"))?.let { g ->
            return acc { if (it.search(g[1])) ok("Ищу ${g[1]}") else fail("Не нашёл поле поиска на экране") }
        }

        // --- ввод текста ---
        if (t("(?:отправь|отправить|отправляй|шли|жми отправить|нажми отправить)(?: сообщение)?"))
            return acc { if (it.clickAny("отправить", "send") || it.enter()) ok("Отправлено") else fail("Не нашёл кнопку отправки") }
        if (has("^(?:очисти|сотри|удали) (?:текст|поле|строку)")) return acc { it.setText("", false); ok("Очищено") }
        f("^(?:допиши|добавь) (.+)")?.let { g -> return acc { it.setText(g[1], true); ok("Дописано") } }
        if (t("диктую|диктуй|напиши")) return acc { speak("Диктуйте", force = true); startDictation { x -> typeSendOnly(it, x) } }
        f("^(?:напиши|набери|введи|впиши|напечатай)(?: (?:сообщение|текст|ответ))? (.+)")?.let { g ->
            if (g[1] in setOf("сообщение", "текст", "ответ")) return acc { speak("Диктуйте", force = true); startDictation { x -> typeSendOnly(it, x) } }
            return acc { if (it.typeSmart(cap(g[1]))) ok("Текст введён") else fail("Не вижу поле ввода. Открой чат и нажми на строку сообщения") }
        }
        f("^(?:нажми|кликни|тапни|выбери|нажать)(?: на)? (.+)")?.let { g ->
            return acc { if (it.smartClick(g[1])) ok("Нажал: ${g[1]}") else fail("Не вижу на экране: ${g[1]}") }
        }

        // --- приложения ---
        f("^(?:открой|открыть|запусти|запустить|зайди в|зайди на|зайди|войди в|включи|перейди в|перейди на|давай)(?: приложение)? (.+)")?.let { g ->
            if (openApp(c, a, g[1], true)) return
            val songs = Music.search(g[1])
            if (songs.isNotEmpty() && s.startsWith("включи")) { Music.play(songs, songs.size >= 5); return ok("Включаю ${Music.nowPlaying()}") }
            return fail("Не нашёл приложение или песню ${g[1]}. Похожие приложения: $lastSug")
        }
        fail("Не понял: $s")
    }

    private fun typeSendOnly(a: ControlService, x: String) {
        if (a.typeSmart(cap(x))) ok("Готово") else fail("Не вижу поле ввода")
    }
}
