package com.voicectl

import java.util.Calendar
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

private val TR = mapOf(
    'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e", 'ё' to "e", 'ж' to "j", 'з' to "z",
    'и' to "i", 'й' to "i", 'к' to "k", 'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r",
    'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f", 'х' to "h", 'ц' to "c", 'ч' to "c", 'ш' to "s", 'щ' to "s",
    'ы' to "i", 'э' to "e", 'ю' to "u", 'я' to "a")

/** Фонетический ключ: кириллица и латиница сводятся к одному виду (монстер ≈ monster). */
fun phon(s: String): String {
    val sb = StringBuilder()
    for (ch in s.lowercase()) {
        val t = TR[ch]
        if (t != null) sb.append(t) else if (ch in 'a'..'z' || ch.isDigit()) sb.append(ch)
    }
    val r = sb.toString().replace("ph", "f").replace("sh", "s").replace("ch", "c").replace("th", "t")
        .replace('y', 'i').replace('w', 'v').replace('q', 'k').replace('x', 'k').replace('c', 'k')
    return Regex("(.)\\1+").replace(r, "$1")
}

fun skel(s: String): String {
    val p = phon(s)
    val k = p.filter { it !in "aeiou" }
    return if (k.length >= 2) k else p
}

fun lev(a: String, b: String): Int {
    if (a.isEmpty()) return b.length
    if (b.isEmpty()) return a.length
    var p = IntArray(b.length + 1) { it }
    for (i in 1..a.length) {
        val c = IntArray(b.length + 1); c[0] = i
        for (j in 1..b.length) c[j] = minOf(p[j] + 1, c[j - 1] + 1, p[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        p = c
    }
    return p[b.length]
}

fun sim1(a: String, b: String): Double { val m = max(a.length, b.length); return if (m == 0) 0.0 else 1.0 - lev(a, b).toDouble() / m }

/** Нечёткое сходство двух строк на слух (0..1). */
fun fz(a: String, b: String): Double {
    val x = phon(a); val y = phon(b)
    if (x.isEmpty() || y.isEmpty()) return 0.0
    return (sim1(x, y) + sim1(skel(a), skel(b))) / 2
}

fun cap(s: String) = s.replaceFirstChar { it.uppercase() }

// ---------- числа словами ----------
private val NU = mapOf("ноль" to 0, "один" to 1, "одна" to 1, "одну" to 1, "два" to 2, "две" to 2, "три" to 3, "четыре" to 4,
    "пять" to 5, "шесть" to 6, "семь" to 7, "восемь" to 8, "девять" to 9, "десять" to 10, "одиннадцать" to 11,
    "двенадцать" to 12, "тринадцать" to 13, "четырнадцать" to 14, "пятнадцать" to 15, "шестнадцать" to 16,
    "семнадцать" to 17, "восемнадцать" to 18, "девятнадцать" to 19, "двадцать" to 20, "тридцать" to 30, "сорок" to 40,
    "пятьдесят" to 50, "шестьдесят" to 60, "семьдесят" to 70, "восемьдесят" to 80, "девяносто" to 90, "сто" to 100,
    "двести" to 200, "триста" to 300, "четыреста" to 400, "пятьсот" to 500, "шестьсот" to 600, "семьсот" to 700,
    "восемьсот" to 800, "девятьсот" to 900)

fun numWords(s: String): String {
    val out = ArrayList<String>()
    var total = 0L; var cur = 0L; var inNum = false
    fun flush() { if (inNum) { out.add((total + cur).toString()); total = 0L; cur = 0L; inNum = false } }
    for (tok in s.split(" ")) {
        val v = NU[tok]
        when {
            v != null -> { cur += v; inNum = true }
            tok.startsWith("тысяч") && inNum -> { total += (if (cur == 0L) 1L else cur) * 1000L; cur = 0L }
            tok.startsWith("миллион") && inNum -> { total += (if (cur == 0L) 1L else cur) * 1000000L; cur = 0L }
            else -> { flush(); out.add(tok) }
        }
    }
    flush()
    return out.joinToString(" ")
}

// ---------- калькулятор ----------
private class P(val s: String) {
    var i = 0
    fun peek(): Char = if (i < s.length) s[i] else '\u0000'
    fun expr(): Double {
        var v = term()
        while (true) { val c = peek(); if (c == '+') { i++; v += term() } else if (c == '-') { i++; v -= term() } else break }
        return v
    }
    fun term(): Double {
        var v = pw()
        while (true) { val c = peek(); if (c == '*') { i++; v *= pw() } else if (c == '/') { i++; v /= pw() } else break }
        return v
    }
    fun pw(): Double { val b = un(); return if (peek() == '^') { i++; Math.pow(b, pw()) } else b }
    fun un(): Double { if (peek() == '-') { i++; return -un() }; return atom() }
    fun atom(): Double {
        if (peek() == '(') { i++; val v = expr(); if (peek() == ')') i++; return v }
        if (s.startsWith("sqrt", i)) { i += 4; return Math.sqrt(atom()) }
        val st = i
        while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
        if (st == i) throw IllegalArgumentException("bad")
        return s.substring(st, i).toDouble()
    }
}

fun calc(raw: String): String? {
    var s = numWords(raw.lowercase().replace('ё', 'е')).replace(',', '.')
    s = Regex("(\\d+(?:\\.\\d+)?) ?процент\\S* от (\\d+(?:\\.\\d+)?)").replace(s) { "(${it.groupValues[2]}*${it.groupValues[1]}/100)" }
    s = Regex("корень из (\\d+(?:\\.\\d+)?)").replace(s) { "sqrt(${it.groupValues[1]})" }
    s = s.replace("в квадрате", "^2").replace("в кубе", "^3").replace("в степени", "^")
        .replace(Regex("умножить на|умножь на|помножить на|умноженное на|умножить|×| х | x "), "*")
        .replace(Regex("разделить на|поделить на|делить на|деленное на|÷|:"), "/")
        .replace("плюс", "+").replace("минус", "-").replace(" ", "")
    if (!Regex("[0-9+\\-*/^().sqrt]+").matches(s)) return null
    return try {
        val p = P(s); val v = p.expr()
        if (p.i != s.length || v.isNaN() || v.isInfinite()) null
        else if (v == Math.rint(v) && abs(v) < 1e15) v.toLong().toString()
        else String.format(Locale.US, "%.6f", v).trimEnd('0').trimEnd('.').replace('.', ',')
    } catch (e: Exception) { null }
}

// ---------- время: длительности, часы, песня в конце фразы ----------
private val DUR = Regex("^(?:(\\d+) ?(секунд\\S*|сек\\S*|минут\\S*|мин\\S*|час\\S*)|(полчаса)|(час))(?: и)? ?")

fun parseDur(s: String): Pair<Long, String>? {
    var rest = s; var ms = 0L; var any = false
    while (true) {
        val m = DUR.find(rest) ?: break
        any = true
        ms += when {
            m.groupValues[3].isNotEmpty() -> 1800000L
            m.groupValues[4].isNotEmpty() -> 3600000L
            else -> {
                val n = m.groupValues[1].toLong(); val u = m.groupValues[2]
                n * (if (u.startsWith("сек")) 1000L else if (u.startsWith("мин")) 60000L else 3600000L)
            }
        }
        rest = rest.substring(m.range.last + 1)
    }
    return if (any) ms to rest.trim() else null
}

private val CLK = Regex("^(?:в |на |к )?(\\d{1,2})(?:[: ](\\d{2})| ?час\\S*(?: (\\d{1,2}) ?мин\\S*)?)?(?: ?(утра|вечера|дня|ночи))?")

fun parseClock(s: String, tomorrow: Boolean): Pair<Long, String>? {
    val m = CLK.find(s) ?: return null
    var h = m.groupValues[1].toInt()
    val mi = m.groupValues[2].ifEmpty { m.groupValues[3] }.ifEmpty { "0" }.toInt()
    val p = m.groupValues[4]
    if ((p == "вечера" || p == "дня") && h < 12) h += 12
    if (p == "ночи" && h == 12) h = 0
    if (h > 23 || mi > 59) return null
    val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, mi); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
    if (tomorrow) c.add(Calendar.DAY_OF_YEAR, 1) else if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1)
    return c.timeInMillis to s.substring(m.range.last + 1).trim()
}

fun splitSong(s: String): Pair<String, String?> {
    val m = Regex(" ?(?:и |с |на |под )?(?:включи |поставь )?(?:песн\\S*|мелоди\\S*|трек\\S*) (.+)$").find(s) ?: return s to null
    return s.substring(0, m.range.first).trim() to m.groupValues[1].trim()
}
