package com.voicectl

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** «Уши и голос»: слушает в фоне, быстро реагирует на короткие команды, ведёт диктовку, отвечает голосом. */
class VoiceService : Service() {
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsOk = false
    @Volatile private var speaking = false
    @Volatile private var fired = false
    private val h = Handler(Looper.getMainLooper())
    private var armed = 0L
    private var wl: PowerManager.WakeLock? = null
    private val q = java.util.ArrayDeque<Pair<String, String>>()
    private val lr = Runnable { listen() }
    private fun sched(d: Long) { h.removeCallbacks(lr); h.postDelayed(lr, d) }

    override fun onBind(i: Intent?): IBinder? = null

    private val lst = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) { fired = false }
        override fun onBeginningOfSpeech() { if (Music.playing) Music.duck(true) }
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, p: Bundle?) {}

        // Быстрый путь: «Джарвис, стоп / следующая / громче» срабатывает по частичному результату, не дожидаясь конца фразы
        override fun onPartialResults(p: Bundle?) {
            if (Brain.dict != null || fired) return
            val l = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
            val s = Brain.norm(l.firstOrNull() ?: return)
            val cmd = findWake(s, Brain.names(this@VoiceService))?.trim(' ', ',', '.', '!') ?: return
            if (Brain.isInstant(cmd)) { fired = true; Music.duck(false); Brain.go(this@VoiceService, cmd) }
        }

        override fun onError(e: Int) {
            Music.duck(false)
            when (e) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { Brain.log("✖ Нет разрешения на микрофон"); stopSelf() }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> { sr?.destroy(); sr = null; sched(600) }
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> sched(30)
                else -> sched(1000)
            }
        }

        override fun onResults(res: Bundle?) {
            Music.duck(false)
            if (fired) fired = false else res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.let { handle(it) }
            sched(30)
        }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("vc", "Голосовое управление", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "vc").setContentTitle("Голосовое управление")
            .setContentText("Слушаю: имя бота + команда").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(1, n)
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { Brain.log("✖ Нет службы распознавания речи (Google)"); stopSelf(); return START_NOT_STICKY }
        if (!Brain.running) {
            Brain.running = true
            wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "voicectl:listen").apply { acquire() }
            Music.init(this)
            if (Music.count() == 0) Thread { try { Brain.log("🎵 В базе песен: " + Music.rescan()) } catch (e: Exception) { } }.start()
            tts = TextToSpeech(this) { st ->
                val e = tts
                if (st == TextToSpeech.SUCCESS && e != null) {
                    e.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(u: String?) {}
                        override fun onDone(u: String?) { h.post { nextUtt() } }
                        override fun onError(u: String?) { h.post { nextUtt() } }
                    })
                    ttsOk = true
                }
            }
            Brain.say = { m, l -> h.post { speakNow(m, l) } }
            Brain.log("🎧 Слушаю. Имя бота: " + Brain.names(this).joinToString(", "))
            listen()
        }
        return START_STICKY
    }

    // ---- голос: очередь фраз с переключением языка (для переводчика) ----
    private fun speakNow(m: String, lang: String) {
        if (!ttsOk) return
        q.add(m to lang)
        if (!speaking) { speaking = true; sr?.cancel(); nextUtt() }
    }

    private fun nextUtt() {
        val p = q.poll()
        val e = tts
        if (p == null || e == null) { speaking = false; sched(100); return }
        e.setLanguage(Locale.forLanguageTag(p.second))
        e.speak(p.first, TextToSpeech.QUEUE_FLUSH, null, "vc")
    }

    private fun listen() {
        if (!Brain.running || speaking) return
        var r = sr
        if (r == null) { r = SpeechRecognizer.createSpeechRecognizer(this); r.setRecognitionListener(lst); sr = r }
        val dictating = Brain.dict != null
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, if (dictating) 1800L else 700L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, if (dictating) 1500L else 500L))
    }

    /** Ищет имя бота: точно, а если распознавание ошиблось (жарвис/джарвиз) — по звучанию. Возвращает текст после имени. */
    private fun findWake(s: String, ns: List<String>): String? {
        for (n in ns) { val i = s.indexOf(n); if (i >= 0) return s.substring(i + n.length) }
        val toks = s.split(" ")
        for (n in ns) {
            if (n.contains(' ')) continue
            for ((k, tk) in toks.withIndex()) if (tk.length >= 3 && fz(tk, n) >= 0.8) return toks.drop(k + 1).joinToString(" ")
        }
        return null
    }

    private fun handle(l: List<String>) {
        if (l.isEmpty()) return
        val cb = Brain.dict
        if (cb != null) {
            Brain.dict = null
            if (SystemClock.elapsedRealtime() < Brain.dictUntil) {
                if (Brain.norm(l[0]).matches(Regex("отмена|отмени|не надо|стоп"))) Brain.speak("Отменено") else Brain.deliver(cb, l[0])
            }
            return
        }
        val ns = Brain.names(this)
        for (t in l) {
            val rest = findWake(Brain.norm(t), ns)
            if (rest != null) {
                val cmd = rest.trim(' ', ',', '.', '!')
                if (cmd.isEmpty()) { armed = SystemClock.elapsedRealtime() + 10000; Brain.log("👂 Слушаю команду…") }
                else Brain.go(this, cmd)
                return
            }
        }
        if (SystemClock.elapsedRealtime() < armed) { armed = 0; Brain.go(this, Brain.norm(l[0])) }
    }

    override fun onDestroy() {
        Brain.running = false; Brain.say = null; Brain.dict = null
        h.removeCallbacksAndMessages(null)
        sr?.destroy(); tts?.shutdown()
        wl?.let { if (it.isHeld) it.release() }
        Brain.log("⏹ Остановлено")
        super.onDestroy()
    }
}
