package com.voicectl

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Calendar
import java.util.Locale

/** Интернет-сервисы без ключей: перевод (MyMemory) и погода (wttr.in). */
object Net {
    fun get(url: String): String? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 7000; c.readTimeout = 7000; c.setRequestProperty("User-Agent", "VoiceControl")
        c.inputStream.bufferedReader().use { it.readText() }
    } catch (e: Exception) { null }

    private val LANGS = mapOf("английск" to "en", "немецк" to "de", "француз" to "fr", "испанск" to "es", "итальянск" to "it",
        "китайск" to "zh-CN", "японск" to "ja", "корейск" to "ko", "турецк" to "tr", "украинск" to "uk", "польск" to "pl",
        "арабск" to "ar", "португальск" to "pt", "чешск" to "cs", "русск" to "ru")

    fun lang(w: String): String? = LANGS.entries.firstOrNull { w.startsWith(it.key) }?.value

    fun translate(text: String, dst: String): String? {
        val from = if (dst == "ru") "en" else "ru"
        val r = get("https://api.mymemory.translated.net/get?q=" + URLEncoder.encode(text, "UTF-8") + "&langpair=" + from + "%7C" + dst) ?: return null
        return try { JSONObject(r).getJSONObject("responseData").getString("translatedText") } catch (e: Exception) { null }
    }

    fun weather(): String? = get("https://wttr.in/?format=%25C+%25t&lang=ru")?.trim()?.takeIf { it.isNotEmpty() && !it.contains("<") }
}

/** Внутренние заметки (работают при выключенном экране). */
object Notes {
    private fun p(c: Context) = c.getSharedPreferences("vc", 0)
    fun all(c: Context): List<String> = try {
        val a = JSONArray(p(c).getString("notes", "[]"))
        (0 until a.length()).map { a.getString(it) }
    } catch (e: Exception) { emptyList() }
    fun add(c: Context, t: String) { p(c).edit().putString("notes", JSONArray(all(c) + t).toString()).apply() }
    fun clear(c: Context) { p(c).edit().remove("notes").apply() }
}

/** Будильники, таймеры и напоминания: AlarmManager + сохранение, чтобы пережить перезагрузку. */
object Sched {
    private fun prefs(c: Context) = c.getSharedPreferences("vc", 0)

    fun list(c: Context): List<List<String>> =
        (prefs(c).getStringSet("al", emptySet()) ?: emptySet()).map { it.split("|") }.filter { it.size >= 5 }.sortedBy { it[1].toLong() }

    private fun pi(c: Context, id: Int, kind: String = "", text: String = "", song: String = "", flag: Int = PendingIntent.FLAG_UPDATE_CURRENT): PendingIntent? =
        PendingIntent.getBroadcast(c, id, Intent(c, AlarmReceiver::class.java).putExtra("kind", kind).putExtra("text", text)
            .putExtra("song", song).putExtra("id", id), flag or PendingIntent.FLAG_IMMUTABLE)

    fun add(c: Context, at: Long, kind: String, text: String, song: String): Boolean {
        val id = (System.currentTimeMillis() % 100000000L).toInt()
        val set = HashSet<String>(prefs(c).getStringSet("al", emptySet()) ?: emptySet<String>())
        set.add("$id|$at|$kind|${text.replace('|', ' ')}|${song.replace('|', ' ')}")
        prefs(c).edit().putStringSet("al", set).apply()
        return arm(c, id, at, kind, text, song)
    }

    fun arm(c: Context, id: Int, at: Long, kind: String, text: String, song: String): Boolean = try {
        val am = c.getSystemService(AlarmManager::class.java)
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi(c, id, kind, text, song)!!)
        true
    } catch (e: Exception) { false }

    fun fired(c: Context, id: Int) {
        val set = HashSet<String>(prefs(c).getStringSet("al", emptySet()) ?: emptySet<String>())
        set.removeAll { it.startsWith("$id|") }
        prefs(c).edit().putStringSet("al", set).apply()
    }

    fun cancelAll(c: Context): Int {
        val l = list(c)
        val am = c.getSystemService(AlarmManager::class.java)
        for (e in l) pi(c, e[0].toInt(), flag = PendingIntent.FLAG_NO_CREATE)?.let { am.cancel(it) }
        prefs(c).edit().remove("al").apply()
        return l.size
    }

    fun restore(c: Context) {
        val now = System.currentTimeMillis()
        for (e in list(c)) {
            if (e[1].toLong() > now) arm(c, e[0].toInt(), e[1].toLong(), e[2], e[3], e[4]) else fired(c, e[0].toInt())
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Sched.fired(c, i.getIntExtra("id", 0))
        val s = Intent(c, RingService::class.java).putExtra("kind", i.getStringExtra("kind") ?: "alarm")
            .putExtra("text", i.getStringExtra("text") ?: "").putExtra("song", i.getStringExtra("song") ?: "")
        try { c.startForegroundService(s) } catch (e: Exception) { }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Sched.restore(c) }
}

/** Звонит будильник/таймер (с выбранной песней), зачитывает напоминание, помогает найти телефон. */
class RingService : Service() {
    companion object {
        @Volatile var ringing = false
        fun stop(c: Context) { c.stopService(Intent(c, RingService::class.java)) }
    }

    private var mp: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var usedMusic = false
    private val h = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "stop") { stopSelf(); return START_NOT_STICKY }
        val kind = i?.getStringExtra("kind") ?: "alarm"
        val text = i?.getStringExtra("text") ?: ""
        val song = i?.getStringExtra("song") ?: ""
        val title = when (kind) { "timer" -> "Таймер"; "reminder" -> "Напоминание"; "find" -> "Я здесь!"; else -> "Будильник" }
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("ring", "Будильники и таймеры", NotificationManager.IMPORTANCE_HIGH))
        val stop = PendingIntent.getService(this, 1, Intent(this, RingService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "ring").setContentTitle(title).setContentText(text.ifBlank { "Нажми, чтобы выключить" })
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentIntent(stop).setAutoCancel(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(2, n)
        ringing = true
        Brain.wake(this)
        val am = getSystemService(AudioManager::class.java)
        if (kind == "reminder") {
            speakText(text)
        } else {
            if (kind == "find") am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
            if (song.isNotBlank()) {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, (am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * 0.8).toInt(), 0)
                Music.init(this)
                val l = Music.search(song)
                if (l.isNotEmpty()) { Music.play(listOf(l[0]), loop = true); usedMusic = true }
            }
            if (!usedMusic) ringtone()
            h.postDelayed({ stopSelf() }, 300000)
        }
        return START_NOT_STICKY
    }

    private fun ringtone() {
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        try {
            val m = MediaPlayer()
            m.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            m.setDataSource(this, uri)
            m.isLooping = true
            m.prepare(); m.start()
            mp = m
        } catch (e: Exception) { }
    }

    private fun speakText(t: String) {
        tts = TextToSpeech(this) { st ->
            val e = tts
            if (st == TextToSpeech.SUCCESS && e != null) {
                e.setLanguage(Locale("ru", "RU"))
                e.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(u: String?) {}
                    override fun onDone(u: String?) { if (u == "r2") h.post { stopSelf() } }
                    override fun onError(u: String?) { h.post { stopSelf() } }
                })
                e.speak("Напоминание. $t", TextToSpeech.QUEUE_ADD, null, "r1")
                e.speak("Напоминаю: $t", TextToSpeech.QUEUE_ADD, null, "r2")
            }
        }
        h.postDelayed({ stopSelf() }, 60000)
    }

    override fun onDestroy() {
        ringing = false
        h.removeCallbacksAndMessages(null)
        mp?.let { try { it.stop() } catch (_: Exception) {}; it.release() }
        tts?.shutdown()
        if (usedMusic) Music.stop()
        super.onDestroy()
    }
}

/** Милые фразы (отключаются переключателем в приложении). */
object Phrases {
    private fun r(vararg s: String) = s.random()
    private fun hour() = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    fun cute() = r("Конечно!", "С удовольствием!", "Уже делаю!", "Как скажешь!", "Всё для тебя!", "Легко!")
    fun hello() = when (hour()) {
        in 5..10 -> r("Доброе утро! Я уже на посту.", "Привет! Отличное утро для хороших дел.")
        in 11..17 -> r("Привет! Рад тебя слышать!", "Здравствуй! Чем помочь?")
        in 18..22 -> r("Добрый вечер! Чем могу помочь?", "Привет! Как прошёл день?")
        else -> r("Привет! Не спишь? Я рядом.", "Здравствуй, полуночник! Слушаю тебя.")
    }
    fun morning() = r("Доброе утро! Пусть сегодня всё получится. Что делаем?", "С добрым утром! Хорошего тебе дня!", "Доброе утро! Кофе сам не сварится, но я помогу со всем остальным.")
    fun evening() = r("Добрый вечер! Как прошёл день?", "Добрый вечер! Рада помочь, чем только смогу.")
    fun night() = r("Спокойной ночи! Сладких снов.", "Спи спокойно! Завтра будет отличный день.", "Доброй ночи! Я постерегу твой телефон.")
    fun how() = r("Всё отлично, особенно когда ты рядом! А у тебя как?", "Прекрасно! Готов к любым командам.", "Замечательно! Заряд полный, настроение боевое.")
    fun thanks() = r("Всегда пожалуйста!", "Обращайся в любое время!", "Мне только в радость!")
    fun praise() = r("Спасибо, мне очень приятно!", "Стараюсь для тебя!", "Ты тоже молодец!")
    fun love() = r("Ой, я смущаюсь. Ты тоже мне очень дорог!", "Это взаимно! Я всегда на твоей стороне.")
    fun about() = "Я твой голосовой помощник. Включаю музыку, ставлю будильники и таймеры, перевожу, считаю, звоню, пишу сообщения и управляю экраном."
    fun here() = r("Я здесь и слушаю!", "Слышу тебя отлично!", "На связи!")
    fun joke() = r("Почему программисты путают Хэллоуин и Рождество? Потому что тридцать один октябрь равно двадцать пять декабрь.",
        "Телефон спрашивает: ты меня любишь? Ответ: ну, заряд пока есть.",
        "Идеальный будильник — тот, который звонит на минуту позже, чем ты проснулся.")
}
