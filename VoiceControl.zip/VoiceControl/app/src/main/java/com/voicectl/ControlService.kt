package com.voicectl

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** «Руки» бота: нажимает, вводит текст, листает, разблокирует. */
class ControlService : AccessibilityService() {
    companion object { @Volatile var inst: ControlService? = null }

    override fun onServiceConnected() {
        inst = this; Brain.log("✔ Служба доступности подключена")
        if (getSharedPreferences("vc", 0).getBoolean("auto", false) && !Brain.running) {
            try { startForegroundService(Intent(this, VoiceService::class.java)) }
            catch (e: Exception) { Brain.log("ℹ Автозапуск запрещён системой — открой приложение и нажми «Запустить»") }
        }
    }
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private val w: Float get() = resources.displayMetrics.widthPixels.toFloat()
    private val h: Float get() = resources.displayMetrics.heightPixels.toFloat()

    // ---------- поиск элементов ----------
    fun nodes(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo, d: Int) {
            out.add(n)
            if (d < 40) for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, d + 1) }
        }
        val ws = try { windows.mapNotNull { it.root } } catch (_: Exception) { emptyList() }
        (if (ws.isNotEmpty()) ws else listOfNotNull(rootInActiveWindow)).forEach { walk(it, 0) }
        return out
    }

    private fun hit(n: AccessibilityNodeInfo, t: String, exact: Boolean): Boolean {
        val a = (n.text?.toString() ?: "").lowercase().replace('ё', 'е')
        val b = (n.contentDescription?.toString() ?: "").lowercase().replace('ё', 'е')
        return if (exact) a.trim() == t || b.trim() == t else a.contains(t) || b.contains(t)
    }

    fun find(t: String, exact: Boolean = false) =
        nodes().firstOrNull { it.isVisibleToUser && !it.isEditable && hit(it, t, exact) }

    fun clickText(t: String, exact: Boolean = false): Boolean {
        val n = find(t, exact) ?: return false
        return click(n)
    }

    fun clickAny(vararg ts: String): Boolean {
        for (t in ts) if (clickText(t)) return true
        return false
    }

    // ---------- действия ----------
    fun click(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null) {
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent
        }
        val r = Rect(); n.getBoundsInScreen(r)
        return tap(r.exactCenterX(), r.exactCenterY())
    }

    fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long = 300): Boolean {
        val p = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build()
        return dispatchGesture(g, null, null)
    }

    fun tap(x: Float, y: Float) = gesture(x, y, x, y, 50)

    fun scroll(dir: String) {
        val cx = w / 2; val cy = h / 2
        when (dir) {
            "вниз" -> gesture(cx, h * .75f, cx, h * .25f)
            "вверх" -> gesture(cx, h * .25f, cx, h * .75f)
            "влево" -> gesture(w * .8f, cy, w * .2f, cy)
            else -> gesture(w * .2f, cy, w * .8f, cy)
        }
    }

    fun editField(last: Boolean = false): AccessibilityNodeInfo? {
        val all = nodes()
        if (!last) for (n in all) if (n.isFocused && n.isEditable) return n
        val ed = all.filter { it.isEditable && it.isVisibleToUser }
        return if (last) ed.lastOrNull() else ed.firstOrNull()
    }

    fun setText(t: String, append: Boolean, last: Boolean = false): Boolean {
        val f = editField(last) ?: return false
        val old = if (append && !f.isShowingHintText) f.text?.toString() ?: "" else ""
        val txt = if (old.isNotEmpty()) "$old $t" else t
        f.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, txt) }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun enter(): Boolean {
        if (Build.VERSION.SDK_INT >= 30) {
            val f = editField()
            if (f != null && f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) return true
        }
        return clickAny("search", "поиск", "найти", "go")
    }

    fun search(q: String): Boolean {
        if (editField() == null) { clickAny("поиск", "search", "найти"); Thread.sleep(1000) }
        if (!setText(q, false)) return false
        Thread.sleep(500); enter(); return true
    }

    /** Первый результат (видео / строка списка) под строкой поиска. */
    fun firstResult(): Boolean {
        Thread.sleep(1200)
        val best = nodes().filter { it.isVisibleToUser && it.isClickable }
            .map { n -> Rect().also { n.getBoundsInScreen(it) }.let { n to it } }
            .filter { (_, r) -> r.top >= h * .15f && r.height() > h * .05f && r.width() > w * .5f }
            .minByOrNull { it.second.top }
        return if (best != null) click(best.first) else tap(w / 2, h * .35f)
    }

    fun openChat(name: String): Boolean {
        val ks = stems(name).ifEmpty { listOf(name) }
        if (ks.any { clickText(it) } || clickFuzzy(name)) return true
        clickAny("поиск", "search"); Thread.sleep(900)
        if (!setText(name, false)) return false
        Thread.sleep(1500)
        return ks.any { clickText(it) } || clickFuzzy(name) || firstResult()
    }

    /** Нечёткий клик по тексту на экране (Alex ≈ Алекс). */
    fun clickFuzzy(q: String, thr: Double = 0.85): Boolean {
        val best = nodes().filter { it.isVisibleToUser && !it.isEditable && !(it.text ?: it.contentDescription).isNullOrBlank() }
            .map { it to fz(q, (it.text ?: it.contentDescription).toString()) }.maxByOrNull { it.second }
        return best != null && best.second >= thr && click(best.first)
    }

    /** Если уже зашли внутрь чата/экрана — возвращаемся к списку (пока на экране есть поле ввода). */
    fun toRoot() {
        val p0 = currentPkg()
        repeat(3) {
            if (editField() == null || currentPkg() != p0) return
            performGlobalAction(GLOBAL_ACTION_BACK); Thread.sleep(500)
        }
    }

    /** Вводит текст; если поле не в фокусе — тапает по строке ввода внизу и пробует снова. */
    fun typeSmart(t: String, last: Boolean = false): Boolean {
        if (setText(t, false, last)) return true
        tap(w / 2, h * .94f); Thread.sleep(700)
        return setText(t, false, last)
    }

    /** Переключает плитку в быстрых настройках (Wi-Fi, Bluetooth, режим полёта...). */
    fun qsToggle(names: List<String>): Boolean {
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS); Thread.sleep(1000)
        var done = names.any { clickText(it) }
        if (!done) { gesture(w / 2, h * .1f, w / 2, h * .6f, 250); Thread.sleep(700); done = names.any { clickText(it) } }
        Thread.sleep(400); performGlobalAction(GLOBAL_ACTION_HOME)
        return done
    }

    fun currentPkg(): String? = rootInActiveWindow?.packageName?.toString()
    fun fab() = tap(w * .88f, h * .9f)

    fun screenText(): String = nodes().filter { it.isVisibleToUser }
        .mapNotNull { (it.text ?: it.contentDescription)?.toString()?.takeIf { s -> s.isNotBlank() && s.length < 80 } }
        .distinct().take(12).joinToString(". ")

    private val SYN = listOf(
        "крест\\S*|закрыть|закрой|х" to "close|закры|dismiss|×|✕|✖|cross|cancel",
        "меню|три точки|троеточие|ещ[её]|опции" to "more options|еще|меню|menu|overflow|options",
        "поиск|лупа" to "search|поиск", "настройки|шестеренка" to "settings|настройки",
        "лайк|нравится|сердечко" to "like|нравится|favorite|избранное", "поделиться" to "share|поделиться",
        "добавить|плюс" to "add|добавить|create|создать|+", "пропустить" to "skip|пропустить",
        "принять|согласен|разрешить" to "accept|agree|allow|принять|разрешить|согласен",
        "ок|окей" to "ok|ок", "назад" to "navigate up|назад|back", "подписаться" to "subscribe|подписаться",
        "воспроизвести|плей|играть" to "play|воспроизвести|слушать", "отмена" to "cancel|отмена",
        "сохранить" to "save|сохранить", "удалить|корзина" to "delete|удалить|trash|корзина",
        "отправить" to "send|отправить", "скачать" to "download|скачать", "микрофон" to "voice|microphone|микрофон",
        "далее|дальше|продолжить|вперед" to "next|далее|continue|продолжить|дальше")

    /** Понимает «крестик», «меню», «лайк»… по тексту, описанию и id элементов на экране. */
    fun smartClick(q: String): Boolean {
        if (clickText(q, true)) return true
        val keys = SYN.filter { Regex(it.first).matches(q) }.flatMap { it.second.split("|") }
        val all = nodes().filter { it.isVisibleToUser && !it.isEditable }
        for (k in keys) all.firstOrNull { hit(it, k, true) }?.let { return click(it) }
        for (k in keys) if (k.length > 2) all.firstOrNull { hit(it, k, false) || it.viewIdResourceName?.lowercase()?.contains(k) == true }?.let { return click(it) }
        return stems(q).any { clickText(it) }
    }

    /** Яндекс Музыка: плейлист из «Коллекции» или поиск песни. */
    fun yandexPlay(q: String, playlist: Boolean): Boolean {
        if (playlist) {
            clickAny("коллекция", "моя музыка", "collection"); Thread.sleep(1200)
            clickAny("плейлисты", "playlists"); Thread.sleep(1000)
            if (!stems(q).any { clickText(it) }) return false
            Thread.sleep(1500); clickAny("слушать", "воспроизвести", "включить", "play"); return true
        }
        if (!search(q)) return false
        Thread.sleep(2000)
        return stems(q).any { clickText(it) } || firstResult()
    }

    fun unlock(pin: String) {
        gesture(w / 2, h * .85f, w / 2, h * .25f, 250); Thread.sleep(1000)
        for (d in pin) { find(d.toString(), true)?.let { click(it) }; Thread.sleep(180) }
        if (pin.isNotEmpty()) { Thread.sleep(250); clickAny("enter", "ввод") }
    }
}
