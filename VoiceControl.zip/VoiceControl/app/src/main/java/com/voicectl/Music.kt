package com.voicectl

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.PowerManager
import android.provider.MediaStore

data class Track(val id: Long, val title: String, val artist: String, val album: String)

/** Своя база музыки на устройстве (SQLite). */
class MusicDb(c: Context) : SQLiteOpenHelper(c, "vc.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) { db.execSQL("CREATE TABLE t(id INTEGER PRIMARY KEY, title TEXT, artist TEXT, album TEXT)") }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    fun all(): List<Track> {
        val l = ArrayList<Track>()
        readableDatabase.rawQuery("SELECT id,title,artist,album FROM t", null).use {
            while (it.moveToNext()) l.add(Track(it.getLong(0), it.getString(1) ?: "", it.getString(2) ?: "", it.getString(3) ?: ""))
        }
        return l
    }

    fun rescan(c: Context): Int {
        val rows = ArrayList<Track>()
        val m = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        c.contentResolver.query(m, arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM),
            "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, null)?.use {
            while (it.moveToNext()) {
                val ar = it.getString(2) ?: ""
                rows.add(Track(it.getLong(0), it.getString(1) ?: "", if (ar == "<unknown>") "" else ar, it.getString(3) ?: ""))
            }
        }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("t", null, null)
            for (t in rows) db.insert("t", null, ContentValues().apply { put("id", t.id); put("title", t.title); put("artist", t.artist); put("album", t.album) })
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return rows.size
    }
}

/** Встроенный плеер: играет при выключенном экране, не зависит от других приложений. */
object Music {
    private lateinit var app: Context
    private var db: MusicDb? = null
    private var lib: List<Track> = emptyList()
    private var idxs: List<Pair<Track, List<Pair<String, String>>>> = emptyList()
    private var mp: MediaPlayer? = null
    private var queue: List<Track> = emptyList()
    private var idx = 0
    private var vol = 1f
    private var loop = false
    private var fails = 0
    private var focus: AudioFocusRequest? = null
    @Volatile var playing = false
    @Volatile var active = false

    fun init(c: Context) { if (db == null) { app = c.applicationContext; db = MusicDb(app); reload() } }
    private fun reload() { lib = db!!.all(); idxs = lib.map { t -> t to toks(t.title + " " + t.artist) } }
    private fun toks(s: String) = s.lowercase().split(Regex("[^\\p{L}\\p{Nd}]+")).filter { it.length > 1 }
        .map { phon(it) to skel(it) }.filter { it.first.isNotEmpty() }
    private fun attrs() = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()

    fun count() = lib.size
    fun all() = lib
    fun rescan(): Int { val n = db!!.rescan(app); reload(); return n }

    /** Нечёткий поиск по названию и исполнителю, в том числе «монстер леди гага» → Monster / Lady Gaga. */
    fun search(q: String): List<Track> {
        val qs = toks(q)
        if (qs.isEmpty()) return emptyList()
        val sc = idxs.map { (t, tk) -> t to qs.map { (p, s) -> tk.maxOfOrNull { (tp, ts) -> (sim1(p, tp) + sim1(s, ts)) / 2 } ?: 0.0 }.average() }
        val best = sc.maxOfOrNull { it.second } ?: 0.0
        if (best < 0.62) return emptyList()
        return sc.filter { it.second >= best - 0.08 }.sortedByDescending { it.second }.map { it.first }.take(100)
    }

    fun play(l: List<Track>, shuffle: Boolean = false, loop: Boolean = false) {
        if (l.isEmpty()) return
        queue = if (shuffle) l.shuffled() else l
        idx = 0; this.loop = loop; fails = 0
        start()
    }

    private fun start() {
        val t = queue[idx]
        release()
        try {
            val am = app.getSystemService(AudioManager::class.java)
            val fr = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(attrs())
                .setOnAudioFocusChangeListener { if (it == AudioManager.AUDIOFOCUS_LOSS) pause() }.build()
            focus = fr; am.requestAudioFocus(fr)
            val m = MediaPlayer()
            m.setAudioAttributes(attrs())
            m.setWakeMode(app, PowerManager.PARTIAL_WAKE_LOCK)
            m.setDataSource(app, ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, t.id))
            m.setOnCompletionListener { if (loop) start() else next() }
            m.setOnErrorListener { _, _, _ -> fails++; if (fails < queue.size) next() else stop(); true }
            m.setVolume(vol, vol)
            m.prepare(); m.start()
            mp = m; playing = true; active = true; fails = 0
        } catch (e: Exception) { fails++; if (fails < queue.size) next() else stop() }
    }

    private fun release() {
        mp?.let { try { it.stop() } catch (_: Exception) {}; try { it.release() } catch (_: Exception) {} }
        mp = null; playing = false
    }

    fun pause() { try { mp?.pause() } catch (_: Exception) {}; playing = false }
    fun resume() { val m = mp ?: return; try { m.start(); playing = true } catch (_: Exception) {} }
    fun next() { if (queue.isEmpty()) return; idx = (idx + 1) % queue.size; start() }
    fun prev() { if (queue.isEmpty()) return; idx = (idx - 1 + queue.size) % queue.size; start() }
    fun stop() {
        release(); queue = emptyList(); active = false
        focus?.let { try { app.getSystemService(AudioManager::class.java).abandonAudioFocusRequest(it) } catch (_: Exception) {} }
        focus = null
    }
    fun duck(on: Boolean) { vol = if (on) 0.2f else 1f; try { mp?.setVolume(vol, vol) } catch (_: Exception) {} }
    fun nowPlaying(): String = queue.getOrNull(idx)?.let { if (it.artist.isBlank()) it.title else "${it.title}, ${it.artist}" } ?: ""
}
